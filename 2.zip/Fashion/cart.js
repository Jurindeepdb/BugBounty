function updateQuantity(itemName, newQuantity) {
    let cart = JSON.parse(sessionStorage.getItem("cart")) || [];
    const itemIndex = cart.findIndex(item => item.name === itemName);
    if (itemIndex !== -1) {
      if (newQuantity > 3) {
        newQuantity = 3;
      }
      cart[itemIndex].quantity = newQuantity;
      
      if (newQuantity === "0" || newQuantity === 0) {
        cart.splice(itemIndex, 1);
      }
    }

    sessionStorage.setItem("cart", JSON.stringify(cart));

    displayCartItems();
}

function displayCartItems() {
  const cart = JSON.parse(sessionStorage.getItem("cart")) || [];
  const cartItemsContainer = document.getElementById("cartItems");
  const cartTotalElement = document.getElementById("cartTotal");
  
  cartItemsContainer.innerHTML = "";
  
  let total = 0;

  cart.forEach(item => {
    const cartItem = document.createElement("div");
    cartItem.classList.add("cart__item");
    
    cartItem.innerHTML = `
      <img src="${item.img}" alt="${item.name}">
      <div class="cart__item-details">
        <h3>${item.name}</h3>
        <p>Price: $${item.price}</p>
        <p>Quantity: 
          <input type="number" class="cart__quantity" value="${item.quantity}" min="0" 
            onchange="updateQuantity('${item.name}', this.value)">
        </p>
      </div>
      <p class="cart__item-total">Total: $${(item.price * item.quantity).toFixed(2)}</p>
    `;
    
    cartItemsContainer.appendChild(cartItem);
    total += item.price * item.quantity;
  });

  cartTotalElement.textContent = total.toFixed(2);
}

displayCartItems();
