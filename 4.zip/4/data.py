import json
import yaml
import sys
def load_yaml_config(yaml_file):
    """Load YAML configuration file."""
    with open(yaml_file, "r", encoding="utf-8") as file:
        return yaml.safe_load(file)  
def load_json_data(json_file):
    """Load JSON data from a file."""
    with open(json_file, "r", encoding="utf-8") as file:
        return json.load(file)
config = load_yaml_config("data.yaml")
json_file_path = config["name"]["json_file"]
data = load_json_data(json_file_path)
def get_user_info():
    while True:
        try:
            user_id = input("Enter user ID (1-20) or 0 to exit: ")
            if user_id == 0:
                print("Exiting...")
                break
            user = next((u for u in data["users"] if u["id"] == user_id), None)
            if user:
                name = user.get("name")
                email = user.get("email")
                age = user.get("age")
                role = user.get("role")
                phone = user.get("phone")
                address = user.get("address")
                street = address.get("street")
                city = address.get("city")
                print(f"\nUser Found: {name}")
                print(f"Email: {email}")
                print(f"Age: {age}")
                print(f"Role: {role}")
                print(f"Phone: {phone}")
                print(f"Address: {street}, {city}")
                print("-" * 30)
                if email is None:
                    print("\nKeyError: 'incomplete data'")
                    sys.exit(1)
            else:
                print("User not found. Try again.")
        except ValueError:
            print("Invalid input! Please enter a number.")
get_user_info()
