#ifndef MATH_OPERATIONS_H
#define MATH_OPERATIONS_H

int add(int a, int b);

#endif