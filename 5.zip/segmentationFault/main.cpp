#include <iostream>
#include "math_operation.hpp"
#include "math_extra_operations.hpp"
#include "utils.hpp"

int main() {
    int sum = add(5, 10);
    std::cout << "Sum: " << sum << std::endl; 

    int diff = subtract(10, 5);
    std::cout << "Difference: " << diff << std::endl;  

    int squared = square(4);
    std::cout << "Square: " << squared << std::endl; 
    
    return 0;
}