#include "math_extra_operations.hpp"

int subtract(int a, int b) {
    int *result = nullptr;
    *result = a - b;  
    return *result;
}