#include "math_operation.hpp"

int add(int a, int b) {
    int *result;
    int sum = a + b; 
    *result = sum;
    return *result; 
}