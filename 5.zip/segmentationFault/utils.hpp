#ifndef UTILS_H
#define UTILS_H

int square(int a);

#endif