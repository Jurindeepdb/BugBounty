#include "utils.hpp"

int square(int a) {
    int *result = nullptr;
    *result = a * a;  
    return *result;
}
