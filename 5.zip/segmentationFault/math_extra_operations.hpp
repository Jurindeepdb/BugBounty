#ifndef MATH_EXTRA_OPERATIONS_H
#define MATH_EXTRA_OPERATIONS_H

int subtract(int a, int b);

#endif