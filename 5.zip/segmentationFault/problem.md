# Bug Bounty Challenge

## Problem Statement
Your task is to identify and fix segmentation faults in a C++ program. The codebase consists of multiple files, each containing subtle issues that may cause the program to crash. Debug the code, find the problematic lines, and resolve the segmentation faults.


## How to Run
To compile and run the program, use the following commands:
```sh
make        # Builds the executable
./program   # Runs the program
```

## How to Clean
To remove compiled files, run:
```sh
make clean
```

## Objective
- Identify the segmentation faults.
- Fix the issues while maintaining correct functionality.

Good luck debugging!
